<?php

/**
 * Редиректим в ЛК
 * 
 * @author WPPW
 * @link http://wppw.ru
 * **************************** */
defined( 'ABSPATH' ) or exit;

wp_redirect( site_url( '/lk' ) );
exit;
