<?php
/**
 * Share buttons
 * 
 * @author WPPW
 * @link http://wppw.ru
 * **************************** */
defined( 'ABSPATH' ) or exit;
?>
<div class="b-share">
	Поделиться<br><br>
	<script src="https://yastatic.net/share2/share.js"></script>
	<div class="ya-share2" data-curtain data-services="vkontakte,facebook,telegram,viber,whatsapp"></div>
</div>
