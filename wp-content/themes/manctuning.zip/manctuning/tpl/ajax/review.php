<?php
/**
 * Благодарим за отзыв
 * 
 * @author WPPW
 * @link http://wppw.ru
 * **************************** */
defined( 'ABSPATH' ) or exit;

ob_start();
?>

<h3>Спасибо за отзыв</h3>

<?php
$html = ob_get_clean();
